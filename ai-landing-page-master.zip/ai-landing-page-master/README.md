# AI.Landing-page project

Landing page which can be used as template to generate landing pages by AI.

## Tools
 
 - For UI used [MUI](https://mui.com/)
 - For check if component is in view used to start animation [react-intersection-observer](https://www.npmjs.com/package/react-intersection-observer)

## Data

The entire source of dynamic content comes from the data.json file

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.


# For the future

### Node server:
To generate landing page using data from JSON which should be provided by chat we need to:

- Install Node server with express:
    `npm install express body-parser cors archiver simple-git`

- Configure server. Create server.js file inside root folder and use that code:
```
const express = require('express');
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const { exec } = require('child_process');
const simpleGit = require('simple-git');

const app = express();
const PORT = process.env.PORT || 5000;
const REPO_URL = 'https://github.com/your-username/your-repo.git';
const REPO_DIR = path.join(__dirname, 'repo');

app.use(express.json());
app.use(require('cors')());

app.post('/generate', (req, res) => {
  const data = req.body;

  if (!data) {
    return res.status(400).send('No data provided');
  }

  // Clone repo to get template
  const git = simpleGit();
  git.clone(REPO_URL, REPO_DIR, [], (err) => {
    if (err) {
      console.error('Failed to clone repository', err);
      return res.status(500).send('Failed to clone repository');
    }

    // create data.json in repo
    const filePath = path.join(REPO_DIR, 'src', 'data.json');

    fs.writeFile(filePath, JSON.stringify(data, null, 2), (err) => {
      if (err) {
        console.error('Failed to save data', err);
        return res.status(500).send('Failed to save data');
      }

      // Install dependencies
      exec('npm install', { cwd: REPO_DIR }, (installError, installStdout, installStderr) => {
        if (installError) {
          console.error(`npm install error: ${installError}`);
          return res.status(500).send('Failed to install dependencies');
        }
        
        console.error(`npm install stderr: ${installStderr}`);

        // Build react app
        exec('npm run build', { cwd: REPO_DIR }, (buildError, buildStdout, buildStderr) => {
          if (buildError) {
            console.error(`npm run build error: ${buildError}`);
            return res.status(500).send('Failed to build project');
          }
          
          console.error(`npm run build stderr: ${buildStderr}`);

          // Create zip file from project catalog
          const output = fs.createWriteStream(path.join(__dirname, 'build.zip'));
          const archive = archiver('zip', {
            zlib: { level: 9 }
          });

          output.on('close', () => {
            console.log(`Zip file created: ${archive.pointer()} total bytes`);
            res.download(path.join(__dirname, 'build.zip'));
          });

          archive.on('error', (err) => {
            throw err;
          });

          archive.pipe(output);
          archive.directory(path.join(REPO_DIR, 'build'), false);
          archive.finalize();
        });
      });
    });
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
```
- to generate we should send POST request to api `/generate`, here is curl example:
`curl -X POST http://localhost:5000/generate -H "Content-Type: application/json" -d @data.json --output generated-website.zip`

### NOTES!

- Make sure the repository URL (REPO_URL) is correct.
- If the repository is private, you will need to use an access token or SSH to clone it.
- Be sure to add logic to clean up the old repository clone before cloning the new one to avoid file overwrite issues.
