import { createTheme } from '@mui/material';
import colors from './colors';

export const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: colors.RED,
    },
    text: {
      primary: colors.WHITE,
      secondary: colors.TEXT_LIGHT,
    },
    background: {
      default: colors.BLACK,
      paper: colors.CHAT_BG,
    },
  },
  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 960,
      lg: 1280,
      xl: 1920,
    },
  },
  typography: {
    fontFamily: 'Outfit, Arial, sans-serif',
    h1: {
      fontSize: '2rem',
      lineHeight: '4rem',
      fontWeight: '600',
      background: colors.LINEAR_GRADIENT,
      backgroundClip: 'text',
      '-webkit-background-clip': 'text',
      '-webkit-text-fill-color': 'transparent',
      '@media (min-width: 600px)': {
        fontSize: '3rem',
      }
    },
    h2: {
      fontSize: '1rem',
      lineHeight: '2rem',
      fontWeight: '400',
      color: colors.WHITE,
      '@media (min-width: 600px)': {
        fontSize: '2rem',
        lineHeight: '2.75rem',
      }
    },
    h3: {
      fontSize: '1.125rem',
      lineHeight: '1.75rem',
      fontWeight: '600',
      color: colors.TEXT_LIGHT_WHITE,
      paddingBottom: '1.5rem'
    },
    h4: {
      fontSize: '1rem',
      lineHeight: '1.5rem',
      fontWeight: '600',
      color: colors.TEXT_LIGHT_GREY
    },
    h5: {
      fontSize: '0.875rem',
      lineHeight: '1.25rem',
      fontWeight: '450',
      color: colors.TEXT_LIGHT
    },
    subtitle1: {
      fontSize: '1.5rem',
      lineHeight: '3rem',
      fontWeight: '600',
      color: colors.GREEN,
      '@media (min-width: 600px)': {
        fontSize: '2.5rem',
      }
    },
    subtitle2: {
      fontSize: '1.5rem',
      lineHeight: '3rem',
      fontWeight: '600',
      color: colors.RED,
      '@media (min-width: 600px)': {
        fontSize: '2.5rem',
      }
    },
    body1: {
      fontSize: '3rem',
      lineHeight: '3.5rem',
      fontWeight: '600',
      color: colors.WHITE,
      '@media (min-width: 600px)': {
        fontSize: '4rem',
      }
    },
    body2: {
      fontSize: '1.5rem',
      lineHeight: '2rem',
      fontWeight: '400',
      color: colors.TEXT_LIGHT
    }
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          height: '3rem',
          width: '8rem',
          borderRadius: '2.2rem',
          textTransform: 'none',
          letterSpacing: '0.04rem',
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          fontSize: '1rem!important',
          borderRadius: '1rem',
          '&.Mui-focused': {
            '& .MuiOutlinedInput-notchedOutline': {
              border: '1px solid white',
            },
          }
        }
      }
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          minHeight: '8rem',
          justifyContent: 'center',
          backgroundColor: 'transparent',
          backgroundImage: 'none',
          boxShadow: 'none',
          borderBottom: 'none',
          color: 'inherit',
        },
      },
    }
  }
})

export default darkTheme;
