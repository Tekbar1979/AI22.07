const API_BASE_URL = 'https://landing-api.primotly.ai'

export default API_BASE_URL;
