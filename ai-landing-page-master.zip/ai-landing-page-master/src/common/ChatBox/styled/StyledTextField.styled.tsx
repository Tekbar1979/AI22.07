import { styled } from '@mui/material/styles';
import TextField from '@mui/material/TextField';

const StyledTextField = styled(TextField)(() => ({
  width: '100%',
  color: '#f7f7f8',
  border: 'none',
  borderRadius: '1rem',
  fontSize: '1rem'
}));

export default StyledTextField;
