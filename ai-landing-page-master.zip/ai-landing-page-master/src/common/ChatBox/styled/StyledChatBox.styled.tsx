import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';

const StyledChatBox = styled(Box)(() => ({
  maxHeight: '40vh',
  overflowY: 'auto',
  display: 'flex',
  marginBottom: '1rem',
  flexDirection: 'column',
  '&::-webkit-scrollbar': {
    display: 'none',
  },
  '-ms-overflow-style': 'none',
  'scrollbar-width': 'none',
}));

export default StyledChatBox;
