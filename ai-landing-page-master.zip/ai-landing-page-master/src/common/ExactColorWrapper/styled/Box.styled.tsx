import styled from '@emotion/styled';
import { Box } from '@mui/material';

const StyledBox = styled(Box)(({ color }) => ({
  '& svg:first-of-type': {
    '& path': {
      fill: `${color}!important`,
    },
  },
}));

export default StyledBox;
