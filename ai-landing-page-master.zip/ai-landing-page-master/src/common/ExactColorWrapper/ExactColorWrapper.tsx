import React from 'react';
import StyledBox from './styled/Box.styled';

interface ExactColorWrapperProps {
  color: string;
  children: React.ReactNode;
}
export default function ExactColorWrapper({ color, children }: ExactColorWrapperProps) {
  return (<StyledBox color={color}>{children}</StyledBox>);
}
