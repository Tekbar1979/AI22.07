import { styled } from '@mui/material/styles';
import Toolbar from '@mui/material/Toolbar';

const StyledToolbar = styled(Toolbar)(({ theme }) => ({
  alignItems: 'center',
  justifyContent: 'center',
  padding: '2.5rem',
  background: 'transparent',
  display: 'flex',
  [theme.breakpoints.up('md')]: {
    justifyContent: 'start',
  }
}));

export default StyledToolbar;
