import React from 'react';
import { AppBar, CardMedia } from '@mui/material';
import ExactColorWrapper from 'common/ExactColorWrapper/ExactColorWrapper';
import StyledToolbar from './styled/StyledToolbar.styled';

// add props to Navbar function when will be dynamic logo url
// interface NavbarProps {
//   logoUrl: string;
// }

export default function NavBar() {

  return (
    <AppBar position="static">
      <StyledToolbar>
        <ExactColorWrapper color="white">
          { /* Use logoUrl for dynamic path in future when generate landingPage */ }
          <CardMedia
            component="img"
            loading="lazy"
            src="/logo.svg"
            alt="Logo"
          />
        </ExactColorWrapper>
      </StyledToolbar>
    </AppBar>
  )
}
