export interface BottomSectionItem {
  "content": string;
  "value": number;
}

export interface SectionProps {
  sectionData: {
    title: string;
    bottomSectionItems: BottomSectionItem[];
  }
}
