import React from 'react';
import { Box, Typography, Grid } from '@mui/material';
import Background from 'assets/backgrounds/patternbg.svg';
import { SectionProps } from './interfaces';
import BottomSectionItem from './BottomSectionItem/BottomSectionItem';


export default function Section({ sectionData }: SectionProps){

  return(
    <Box
      py={{ xs: 2, sm: 8, md: 10, lg: 12, xl: 15 }}
      sx={{
        backgroundSize: 'cover',
        backgroundImage: `
          radial-gradient(100% 100% at 50% 0%, #1C2026 0%, rgba(0, 0, 0, 0) 100%),
          url(${Background})`,
        backgroundBlendMode: 'overlay',
      }}
    >
      <Grid container spacing={3} pt={2} px={4}>
        <Grid
          item
          xs={12}
          textAlign="center"
          mb={{ xs: 2, md: 10 }}
        >
          <Typography variant="h1" sx={{ whiteSpace: 'pre-line' }}>{sectionData.title}</Typography>
        </Grid>
        <Grid item xs={12} md={12} display="flex">
          <Grid container spacing={5}>
            {sectionData.bottomSectionItems.map((item) => (
              <BottomSectionItem key={`pain-point-${item.content}`} content={item.content} value={item.value} />
            ))}
          </Grid>
        </Grid>
      </Grid>
    </Box>
  )
}
