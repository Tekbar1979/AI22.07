import React, { useEffect, useState } from 'react';
import { ThemeProvider } from '@mui/material/styles';
import { CssBaseline, Box } from '@mui/material';
import Navbar from 'comoponents/Navbar/Navbar';
import ChatSection from 'comoponents/ChatSection/ChatSection';
import Footer from 'comoponents/Footer/Footer';
import MiddleSection from 'comoponents/MiddleSection/Section';
import BottomSection from 'comoponents/BottomSection/Section';
import { darkTheme} from 'config/material-ui/theme';
import Background from 'assets/backgrounds/background-ai.svg';
import { Data } from './interfaces';

export default function App() {
  const [data, setData] = useState<Data | null>(null)

  useEffect(() => {
    fetch('/data.json')
        .then((response) => response.json())
        .then((dataResponse) => setData(dataResponse));
  }, []);

  if (!data) return <div>Loading...</div>;

  return (
     <ThemeProvider theme={darkTheme}>
       <CssBaseline />
       <Box
         sx={{
           backgroundImage: `url(${Background})`,
           backgroundSize: 'cover',
           backgroundPosition: 'center',
           display: 'flex',
           flexDirection: 'column',
         }}
       >
         {/* add logoUrl={data.navbar.logoUrl} when template will generate landing pages */}
         <Navbar />
         <ChatSection title={data.header.title} />
       </Box>
       <MiddleSection sectionData={data.body.sections.middleSection} />
       <BottomSection sectionData={data.body.sections.bottomSection} />
       <Footer
         socials={data.footer.socials}
         content={data.footer.content}
         privacyPolicyLink={data.footer.privacyPolicyLink}
         termsLink={data.footer.termsLink}
         vat={data.footer.vat}
         regon={data.footer.regon}
         krs={data.footer.krs}
       />
     </ThemeProvider>
  );
}
