import { MiddleSectionItem } from '../MiddleSection/interfaces';


interface SectionItems {
  content: string;
  value: number;
  resultType: string;
  arrowDir: string;
}

export interface Data {
  theme: string;
  navbar: {
    logoUrl: string;
  }
  header: {
    title: string;
  };
  body: {
    sections: {
      middleSection: {
        title: string;
        middleSectionItems: SectionItems[]
      }
      bottomSection: {
        title: string;
        bottomSectionItems: SectionItems[]
      }
    };
  };
  footer: {
    socials: {
      linkedIn: string;
      instagram: string;
      facebook: string;
    },
    content: string;
    contactUsLink: string;
    privacyPolicyLink: string;
    termsLink: string;
    vat: string;
    regon: string;
    krs: string;
  };
}
