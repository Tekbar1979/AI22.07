export interface MiddleSectionItem {
  content: string;
  value: number;
  resultType: string;
  arrowDir: string;
}

export interface SectionProps {
  sectionData: {
    title: string;
    middleSectionItems: MiddleSectionItem[]
  }
}
