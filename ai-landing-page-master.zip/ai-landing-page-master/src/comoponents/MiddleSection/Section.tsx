import React from 'react';
import { Typography, Box } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2';
import MiddleSectionItem from './MiddleSectionItem/MiddleSectionItem';
import { SectionProps } from './interfaces';

export default function Section({ sectionData }: SectionProps) {

  return (
    <Box
      py={{ xs: 2, sm: 8, md: 10, lg: 12, xl: 15 }}
      px={4}
    >
      <Grid container>
        <Grid xs={12} lg={5} lgOffset={1} mb={{ xs: 2, md: 10 }}>
          <Typography
            variant="h1"
            sx={{
              whiteSpace: 'pre-line',
              textAlign: { xs: 'center', lg: 'left' },
            }}
          >
            {sectionData.title}
          </Typography>
        </Grid>
        <Grid xs={12} lg={5}>
          {sectionData.middleSectionItems.map((item, index) => (
            <MiddleSectionItem
              key={`kpi-${item.content}`}
              content={item.content}
              value={item.value}
              resultType={item.resultType}
              arrowDir={item.arrowDir}
              isLast={index === sectionData.middleSectionItems.length - 1}
              isFirst={index === 0}
            />
          ))}
        </Grid>
      </Grid>
    </Box>
  );
}
