export interface SocialLinks {
  linkedIn: string;
  facebook: string;
  instagram: string;
}

export interface FooterProps {
  socials?: SocialLinks,
  content?: string;
  privacyPolicyLink?: string;
  termsLink?: string;
  vat?: string;
  regon?: string;
  krs?: string;
}
