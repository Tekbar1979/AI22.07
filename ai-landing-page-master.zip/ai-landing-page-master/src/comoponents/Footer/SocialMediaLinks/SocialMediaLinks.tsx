import React from 'react';
import { Link, SvgIcon, Box } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2';
import { SocialLinks } from 'comoponents/Footer/interfaces';
import FacebookIcon from './iconComponents/FacebookIcon';
import InstagramIcon from './iconComponents/InstagramIcon';
import LinkedInIcon from './iconComponents/LinkedInIcon';


interface SocialLinksProps {
  socials: SocialLinks
}
export default function SocialMediaLinks({ socials }: SocialLinksProps){
  return (
    <Grid container spacing={2}>
      <Grid xs={8} xsOffset={2} md={4} mdOffset={0}>
        <Box display="flex" justifyContent="space-between">
          <Link href={socials.facebook} target="_blank" rel="nofollow noopener">
            <SvgIcon component={FacebookIcon} />
          </Link>
          <Link href={socials.instagram} target="_blank" rel="nofollow noopener">
            <SvgIcon component={InstagramIcon} />
          </Link>
          <Link href={socials.linkedIn} target="_blank" rel="nofollow noopener">
            <SvgIcon component={LinkedInIcon} />
          </Link>
        </Box>
      </Grid>
    </Grid>
  );
}
