import styled from '@emotion/styled';
import { Link } from '@mui/material';

const StyledLink = styled(Link)(() => ({
  marginBottom: '1.25rem',
  textDecoration: 'none'
}));

export default StyledLink;
