import styled from '@emotion/styled';
import { SvgIcon } from '@mui/material';

const StyledSvgIcon = styled(SvgIcon)(() => ({
  fontSize: '2.5rem',
}));

export default StyledSvgIcon;
