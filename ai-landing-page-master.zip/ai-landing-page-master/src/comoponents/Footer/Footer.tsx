import React from 'react';
import { Grid, Box, CardMedia, Typography } from '@mui/material';
import ExactColorWrapper from 'common/ExactColorWrapper/ExactColorWrapper';
import { FooterProps}  from 'comoponents/Footer/interfaces';
import { useTheme } from '@mui/material/styles';
import StyledLink from './SocialMediaLinks/styled/Link.styled';
import SocialMediaLinks from './SocialMediaLinks/SocialMediaLinks';
import CompanyInfo from './CompanyInfo/CompanyInfo';

export default function Footer({
  socials,
  content,
  privacyPolicyLink,
  termsLink,
  vat,
  regon,
  krs
}: FooterProps){

  const theme = useTheme();
  return(
    <Box
      p={{ xs: 4, sm: 8, md: 10, lg: 12, xl: 15 }}
      mt={{ xs: 5, sm: 0 }}
    >
      <Grid container spacing={2}>
        <Grid item xs={12} md={4} mb={5}>
          <ExactColorWrapper color="white">
            <Box sx={{
              [theme.breakpoints.down('md')]: {
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
              },
            }}
           >
              <CardMedia
                component="img"
                loading="lazy"
                src="/logo.svg"
                alt="Logo"
                sx={{ maxWidth: '11rem' }}
              />
            </Box>
          </ExactColorWrapper>
          {socials && (
            <SocialMediaLinks socials={socials} />
          )}
        </Grid>
        <Grid item xs={12} md={4}>
          {privacyPolicyLink && (
            <StyledLink href={privacyPolicyLink} target="_blank" rel="nofollow noopener" mb={3}>
              <Typography variant="h3">Privacy policy</Typography>
            </StyledLink>
          )}
          {termsLink && (
            <StyledLink href={termsLink} target="_blank" rel="nofollow noopener">
              <Typography variant="h3">Terms</Typography>
            </StyledLink>
          )}
        </Grid>
        <Grid item xs={12} md={4}>
          <Typography variant="h4" mb={5}>{content}</Typography>
          <CompanyInfo vat={vat} regon={regon} krs={krs} />
        </Grid>
      </Grid>
    </Box>
  )
}
