import React from 'react';
import {Grid, Typography} from '@mui/material';

interface CompanyInfoProps {
  vat?: string;
  regon?: string;
  krs?: string;
}

export default function CompanyInfo({ vat, regon, krs}: CompanyInfoProps) {
  return(
    <Grid container spacing={4}>
      <Grid item xs={12} md={6}>
        <Typography variant="h5">VAT-ID</Typography>
        <Typography variant="h4">{vat || 'N/A'}</Typography>
      </Grid>
      <Grid item xs={12} md={6}>
        <Typography variant="h5">REGON</Typography>
        <Typography variant="h4">{regon || 'N/A'}</Typography>
      </Grid>
      <Grid item xs={12} md={6}>
        <Typography variant="h5">KRS</Typography>
        <Typography variant="h4">{krs || 'N/A'}</Typography>
      </Grid>
    </Grid>
  )
}
