import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';

const StyledBox = styled(Box)(({ theme }) => ({
  position: 'relative',
  marginBottom: '0.5rem',
  display: 'flex',
  flexDirection: 'column',
  borderRadius: '2.5rem',
  backgroundColor: theme.palette.background.paper,
  boxShadow: '0 0 20px rgb(85 90 100)',
  border: '1px solid rgba(39, 45, 54, 1)',
  padding: '1.5rem',
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '6rem',
    background: 'linear-gradient(to bottom, rgba(0, 0, 0, 1), rgba(0, 0, 0, 0))',
    zIndex: 1,
    pointerEvents: 'none',
    borderRadius: '2.5rem',
  },
}));

export default StyledBox;
