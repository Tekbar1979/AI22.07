import React, { useEffect, useRef, useState } from 'react';
import { Grid, InputAdornment } from '@mui/material';
import StyledChatBox from 'common/ChatBox/styled/StyledChatBox.styled';
import StyledTextField from 'common/ChatBox/styled/StyledTextField.styled';
import SendIcon from '@mui/icons-material/Send';
import API_BASE_URL from 'config/api/api';
import StyledBox from './styled/StyledBox.styled';

const initialMessage =
  `Welcome! I'm here to provide expert assistance and guidance as you navigate the process of preparing your company's
      CSRD report. The Corporate Sustainability Reporting Directive aims to improve sustainability reporting and ensure that
      companies disclose relevant, comparable, and reliable information about their environmental, social, and governance
      (ESG) impacts. Whether you have questions about the reporting requirements, need help identifying and collecting the
      necessary data, or want advice on presenting your sustainability performance effectively, I'm here to support you every
      step of the way. Feel free to ask any questions you may have, and we'll work together to ensure your CSRD report is
      comprehensive, compliant, and showcases your company's commitment to sustainability. P.S. If you'd like a summary of
      our conversation emailed to you, feel free to provide your email address at any point and I'll send it within 24 hours
      after our chat concludes. Otherwise, please continue our discussion!`;

const additionalPartialModelMessage =
  `If you'd like a summary of our conversation emailed to you at any point, simply provide your email address and I'll send
    it over within 24 hours. Otherwise, feel free to continue our discussion!`;

export default function Chat() {
  const [uniqueID, setUniqueID] = useState('');
  const [message, setMessage] = useState('');
  const chatAreaRef = useRef<HTMLDivElement | null>(null);
  const initialMessageAddedRef = useRef(false);

  useEffect(() => {
    if (!initialMessageAddedRef.current && chatAreaRef.current) {
      const messageElement = document.createElement('div');
      messageElement.className = 'message bot-message';
      messageElement.textContent = initialMessage;
      chatAreaRef.current.appendChild(messageElement);
      initialMessageAddedRef.current = true;
    }

    setUniqueID(`${Date.now()}-${Math.random().toString(36).slice(2, 10)}`);
  }, []);

  const prepareMessagesRequest = (messagesAmount: number, newMessage: string) => {
    const chatArea = chatAreaRef.current;
    if (!chatArea) return [];

    const messageElements = Array.from(chatArea.getElementsByClassName('message'));
    const messages = messageElements.map((messageElement) => {
      if (messageElement.classList.contains('user-message')) {
        return { role: 'user', content: messageElement.textContent };
      }
      if (messageElement.classList.contains('bot-message')) {
        return { role: 'assistant', content: messageElement.textContent };
      }
      return null;
    }).filter(Boolean);

    const truncatedMessages = messages.slice(-messagesAmount);
    truncatedMessages.push({ role: 'user', content: newMessage });

    return truncatedMessages;
  };

  const readStream = (reader: ReadableStreamDefaultReader<Uint8Array>, botMessageElement: HTMLDivElement) => {
    const decoder = new TextDecoder('utf-8');
    let accumulatedResult = '';
    let currentBotMessageElement = botMessageElement;

    const processText = ({ value, done }: ReadableStreamReadResult<Uint8Array>) => {
      if (done) {
        const finalMessageElement = currentBotMessageElement.cloneNode(true) as HTMLDivElement;
        finalMessageElement.textContent = accumulatedResult;
        currentBotMessageElement.replaceWith(finalMessageElement);
        if (chatAreaRef.current) {
          chatAreaRef.current.scrollTop = chatAreaRef.current.scrollHeight;
        }
        return;
      }

      accumulatedResult += decoder.decode(value, { stream: true });
      const updatedMessageElement = currentBotMessageElement.cloneNode(true) as HTMLDivElement;
      updatedMessageElement.textContent = accumulatedResult;
      currentBotMessageElement.replaceWith(updatedMessageElement);
      currentBotMessageElement = updatedMessageElement; // Update the reference to the new element

      if (chatAreaRef.current) {
        chatAreaRef.current.scrollTop = chatAreaRef.current.scrollHeight;
      }

      reader.read().then(processText);
    };

    reader.read().then(processText);
  };


  const sendMessages = async () => {
    const chatAreaReference = chatAreaRef.current;

    if (!message || !chatAreaReference) {
      return;
    }

    const messages = prepareMessagesRequest(6, message.trim());

    const userMessageElement = document.createElement('div');
    userMessageElement.className = 'message user-message';
    userMessageElement.textContent = message.trim();
    chatAreaReference.appendChild(userMessageElement);

    const botMessageElement = document.createElement('div');
    botMessageElement.className = 'message bot-message';
    chatAreaReference.appendChild(botMessageElement);

    try {
      setMessage('');
      const response = await fetch(`${API_BASE_URL}/chat/csrd-ai-model`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user: uniqueID,
          messages,
          additionalPartialModelMessage,
        }),
      });

      if (!response.ok) {
        chatAreaReference.removeChild(userMessageElement);
        chatAreaReference.removeChild(botMessageElement);
        return;
      }

      const reader = response.body?.getReader();

      if (reader) {
        readStream(reader, botMessageElement);
      }
    } catch (error) {
      chatAreaReference.removeChild(userMessageElement);
      chatAreaReference.removeChild(botMessageElement);
    }
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    await sendMessages();
  };

  return (
    <Grid container justifyContent="center">
      <Grid item lg={10}>
        <StyledBox>
          <StyledChatBox>
            <div id="chatArea" ref={chatAreaRef} />
          </StyledChatBox>
          <form id="messageForm" onSubmit={handleSubmit}>
            <StyledTextField
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Enter your message here..."
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <SendIcon onClick={handleSubmit} style={{ cursor: 'pointer' }} />
                  </InputAdornment>
                ),
              }}
            />
          </form>
        </StyledBox>
      </Grid>
    </Grid>
  );
}
