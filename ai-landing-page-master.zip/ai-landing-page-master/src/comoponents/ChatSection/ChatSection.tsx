import React from 'react'
import { Box, Typography } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2';
import Chat from 'comoponents/ChatSection/Chat/Chat';

interface ChatProps {
  title: string;
}

export default function ChatSection({ title }: ChatProps) {

  return(
    <Box pb={5}>
      <Grid container>
        <Grid xs={12} md={6} mdOffset={3} textAlign="center" mt={3} mb={5}>
          <Typography variant="h1" sx={{ whiteSpace: 'pre-line' }}>{title}</Typography>
        </Grid>
        <Grid xs={12} md={10} mdOffset={1} mt={5}>
          <Chat />
        </Grid>
      </Grid>
    </Box>
  )
}
